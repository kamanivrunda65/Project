<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Practical</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>

<body>
        <h1><?php echo e($mailData['title']); ?></h1>
        <br>
        <p><?php echo e($mailData['body']); ?></p>

        <p>Please click the button below to verify your email address</p>
        <br>
        
        <a style="background-color: #371fea;color:#fff;padding:6px 12px;border-radius: 4px;border-color:#fff;" type="button" href="<?php echo e(url('/')); ?>/api/verifyemail/<?php echo e($mailData['email']); ?>">Verify Email</a>
</body>

</html><?php /**PATH G:\xampp\htdocs\Project\practical\resources\views/layouts/verifymail.blade.php ENDPATH**/ ?>