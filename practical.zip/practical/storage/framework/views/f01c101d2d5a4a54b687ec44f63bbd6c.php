<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(URL::asset('asset/style.css')); ?>">
    <title>Register</title>
    <script src="https://code.jquery.com/jquery-3.6.3.min.js" integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script>

</head>
<body>
    <div class="container">
        <form method="post" id="registerform" class="form" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <h2>Hurry Up! Register Now!</h2>
            <div class="form-control">
                <label for="username">Username</label>
                <input type="text" id="username" placeholder="Enter username" name="name">
                <small>Error message</small>
            </div>
            <div class="form-control">
                <label for="email">Email</label>
                <input type="text" id="email" placeholder="Enter email" name="email">
                <small>Error message</small>
            </div>
            <div class="form-control">
                <label>Image</label>
                <input type="file" id="image" name="image" >
                <small>Error message</small>
            </div>
            <div class="form-control">
                <label for="password">Password</label>
                <input type="password" id="password" placeholder="Enter username" name="password">
                <small>Error message</small>
            </div>
            
            <button class="button">Submit</button>
        </form>
    </div>
    
    <script>
         $("form#registerform").submit(function(e) {
        e.preventDefault();
         var formData = new FormData(this);
         console.log(formData);
         })

//          const form = document.getElementById('registerform');
//   form.addEventListener('submit', (event) => {
//     event.preventDefault();
//     checkRequired([username, email, password, image]);
//     const formData = new FormData(form);
//     console.log(formData);
//   })
    </script>
    <script src="<?php echo e(URL::asset('asset/script.js')); ?>"></script>
</body>
</html><?php /**PATH G:\xampp\htdocs\Project\practical\resources\views/layouts/signup.blade.php ENDPATH**/ ?>