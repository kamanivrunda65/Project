<?php

namespace App\Http\Controllers;
use Mail;
use App\Models\User;
use App\Mail\VerifyMail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;;

class AuthController extends Controller
{
    // public function signup()
    // {
    //     return view('layouts.signup');
    // }
    public function loginpage()
    {
        return view('layouts.login');
    }
    public function signupuser(Request $request,User $user)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255|unique:users',
            'password' => 'required|min:8|confirmed',
            'image' => 'nullable|mimes:jpeg,png,jpg',
            'referral_code' => 'nullable',
        ]);
        $user->name=$request->name;
        $user->email=$request->email;
        $user->password=Hash::make($request->password);
        if ($request->hasFile('image')) {
            $photoName = time().'.'.$request->image->extension();
            $request->image->move(public_path('images'), $photoName);
            // store('public/images')
            $user->image = "images/".$photoName;
            // $user->save();
        }
        if($request->hasFile('referral_code')){
            $user->referral_code=$request->referral_code;
        }
        $mailData = [
            'title' => 'Mail from Website',
            'body' => 'This is for verify your Email',
            'email'=>$request->email,
        ];
        Mail::to("$request->email")->send(new VerifyMail($mailData));
        $user->save();

        return response()->json([
            'message' => 'User registered successfully'
        ], 201);
        //dd($user);
    }
    public function verifyemailuser($email,User $user)
    {
        $userid=$user->where('email',"=","$email")->value('id');
        $userdata=$user->find($userid);
        // dd($userdata);
        $userdata->email_verified_at=now();
        $userdata->save();
        return response()->json([
            'message' => 'User email verify successfully'
        ], 201);
        // redirect('/login');

    }
    public function loginuser(Request $request,User $user)
    {
        $validator = Validator::make($request->all(), [
            
            'email' => 'required|email',
            'password' => 'required|min:8',
            
        ]);
        $credentials = $request->only('email', 'password');
        $userid=$user->where('email',"=","$request->email")->value('id');
        if($userid!=null)
        {
            $userdata=$user->find($userid);
            if(Auth::attempt($credentials))
            {
                $verify=$userdata->email_verified_at;
                // dd(Auth::user()->id);
                if ($verify!=null) 
                {
                    return response()->json([
                        'message' => 'User login successfully',
                        'data'=>'1',
                        'userid'=>$request->email
                    ], 201);
                    // return redirect('profile');
                }
                else
                {
                    return response()->json([
                        'message' => 'Please verify your email',
                        'Data'=>'0'
                    ], 201);
                }
            }
            else
            {
                // Auth::logout();
                return response()->json([
                    'message' => 'Incorrect Password',
                    'Data'=>'0'
                ], 201);
                
            }
        }
        else
        {
            return response()->json([
                'message' => 'No Data Found',
                'Data'=>'0'
            ], 201);
        }
    }
    public function updateuser(Request $request,$email,User $user)
    {
        $userid=$user->where('email',"=","$email")->value('id');

        $validator = Validator::make($request->all(), [
            'password' => 'required|min:8',
        ]);
        $userdata=$user->find($userid);
        if(Hash::check($request->password,$userdata->password))
        {
            if ($request->hasFile('name')) 
            {
                $userdata->name=$request->name;
            }
            if ($request->hasFile('email')) 
            {
                $userdata->email_verified_at=null;
                $userdata->email=$request->email;
                $mailData = [
                'title' => 'Mail from Website',
                'body' => 'This is for verify your Email',
                'email'=>$request->email,
                ];
                Mail::to("$request->email")->send(new VerifyMail($mailData));
            }
            if ($request->hasFile('image')) 
            {
                $photoName = time().'.'.$request->image->extension();
                $request->image->move(public_path('images'), $photoName);
                // store('public/images')
                $userdata->image = "images/".$photoName;
            }
            if ($request->hasFile('referral_code')) 
            {
                $userdata->referral_code=$request->referral_code;
            }
            $userdata->save();
            return response()->json([
                'message' => 'User data Update successfully'
            ]);
            //dd($userdata);
        }
        else
        {
            return response()->json([
                'message' => 'Incorrect Password'
            ]);
        }
        
        // $userdata->save();
    }
    public function profile($email,User $user)
    {
        
        if(Auth::check()){
        $id=Auth::user()->id;
        $userdata=$user->find($id);
        //dd($userdata);
        return view('profile')->with(['userdata'=>$userdata]);
        }
    }
}
