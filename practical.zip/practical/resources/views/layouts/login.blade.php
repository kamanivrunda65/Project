<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="{{URL::asset('asset/style.css')}}">
    <title>Register</title>
    <script src="https://code.jquery.com/jquery-3.6.3.min.js" integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script>

</head>
<body>
    <div class="container">
        <form method="post" id="loginuser" class="form" enctype="multipart/form-data" >
            @csrf
            <h2>Login</h2>
           
            <div class="form-control">
                <label for="email">Email</label>
                <input type="text" id="email" placeholder="Enter email" name="email" required>
                <small>Error message</small>
            </div>
           
            <div class="form-control">
                <label for="password">Password</label>
                <input type="password" id="password" placeholder="Enter username" name="password" required>
                <small>Error message</small>
            </div>
            
            <button class="button" onclick="login()">Submit</button>
        </form>
    </div>
    
    <script>
         function login(){
        
        event.preventDefault();
        let FormData = $("#loginuser").serializeArray() ;  
        //console.log(FormData);
        var result = {};
        $.each(FormData, function() {
            result[this.name] = this.value;   
        });
        
        $.ajax({
        url: 'http://localhost:8000/api/login',
        type: 'POST',
        data: result,
        success: function(response) {
             console.log(response);
            if(response.Data==1){
                var id=response.userid;
            
            window.location.href="/profile";
            }
        },
        error: function(error) {
            console.log(error);
        }
    
    });
    }
    </script>
</body>
</html>