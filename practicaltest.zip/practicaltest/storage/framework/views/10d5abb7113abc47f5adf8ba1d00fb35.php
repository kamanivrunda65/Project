<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    .image-size{
        height: 200px;
        width: 286px;
        border: 1px solid #000;
    }
</style>
<br>
<br>

    <div class="container row" id="product-data">
        
    </div>

<script>
    allproduct()
    function allproduct()
    {
        fetch("http://localhost:8000/api/allproduct").then(response=>response.json()).then((res)=>{
            //console.log(res);
            allproduct=""
            res.forEach(element => {
                allproduct+=`<div class="col-lg-3">
            <div class="card" style="width: 18rem;">
                <img src="<?php echo e(URL::asset('${element.image}')); ?>" class="card-img-top image-size" alt="<?php echo e(URL::asset('${element.image}')); ?>">
                    <div class="card-body">
                        <h5 class="card-title">${element.product_name}</h5>
                        <p class="card-text">Price : ${element.price}</p>
                        <button  onclick="addcart(${element.id})" class="btn btn-primary">Add to cart</button>
                    </div>
            </div>
        </div>`
            });
            document.getElementById('product-data').innerHTML=allproduct;
        })
    }
    function addcart(id)
    {
        fetch("http://localhost:8000/api/addcart/"+id).then(response=>response.json()).then((res)=>{
            //console.log(res);
            // allproduct();
            window.location.href="/cart";
        })
    }
</script>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\Project\practicaltest\resources\views/layouts/product.blade.php ENDPATH**/ ?>